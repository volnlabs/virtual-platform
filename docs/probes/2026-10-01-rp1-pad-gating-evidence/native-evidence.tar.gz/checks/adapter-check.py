import json, os, subprocess
from pathlib import Path
repo=Path('/home/utkarsh/Work/volnlabs/axiomos-sim')
fixtures=Path('/tmp/rp1-pad-adapter-fixtures'); fixtures.mkdir(exist_ok=True)
output=Path('/tmp/rp1-pad-end-to-end-verified'); output.mkdir()
header='*** Variables ***\n${MODEL_FILE}    '+str(repo/'backends/renode/peripherals/RP1_GPIO.cs')+'\n\n'
positive=header+(repo/'backends/renode/tests/rp1-gpio.robot').read_text()
invalid=header+(repo/'backends/renode/tests/rp1-gpio-invalid.robot').read_text()
needle='    State Should Contain    0    drive=disabled\n    Execute Command    sysbus WriteDoubleWord 0x30004 0x5a'
assert positive.count(needle)==1
wrong=positive.replace(needle,needle.replace('drive=disabled','drive=high'),1)
(fixtures/'input').write_text('Adapter-only fixture; not a guest image.\n')
checks={}
for name,content,expected in [('positive',positive,0),('invalid',invalid,1),('wrong-drive',wrong,1)]:
 scenario=fixtures/(name+'.robot'); scenario.write_text(content)
 env={k:v for k,v in os.environ.items() if not k.startswith(('AXIOMOS_','VOLN_VP_'))}
 env.update(PATH='/tmp/voln-vp-robot-env/bin:'+env['PATH'],AXIOMOS_KERNEL=str(fixtures/'input'),VOLN_VP_DTB=str(fixtures/'input'),VOLN_VP_VERB='test',VOLN_VP_TEST_MODE='runtime',VOLN_VP_STRICT_MMIO='1',VOLN_VP_TIMEOUT='45s',VOLN_VP_SCENARIO=str(scenario),VOLN_VP_ARTIFACT_DIR=str(output/name))
 with (output/(name+'.log')).open('w') as log:
  result=subprocess.run([str(repo/'backends/renode/adapters/run.sh')],cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=55)
 results=list((output/name).glob('*/result.json')); assert len(results)==1,results
 data=json.loads(results[0].read_text())
 assert result.returncode==expected,(name,result.returncode)
 assert data['completed'] is True and data['strict_mmio'] is True and data['qualification_claims']==[],data
 checks[name]={'exit_code':result.returncode,'result':str(results[0]),'reason':data['reason']}
 print(name,checks[name],flush=True)
(output/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
