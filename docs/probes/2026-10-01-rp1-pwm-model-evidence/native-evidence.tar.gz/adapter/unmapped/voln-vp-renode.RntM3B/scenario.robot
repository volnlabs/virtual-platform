*** Test Cases ***
Unmapped Read Cannot Qualify
    Execute Command    mach create
    ${value}=    Execute Command    sysbus ReadDoubleWord 0x20000
    Should Be Equal As Integers    ${value}    0
